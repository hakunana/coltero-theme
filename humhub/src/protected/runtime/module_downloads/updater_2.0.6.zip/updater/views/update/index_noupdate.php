<div class="panel panel-default">
    <div class="panel-heading"><?php echo Yii::t('UpdaterModule.base', '<strong>Update</strong> HumHub'); ?></div>
    <div class="panel-body">
        
        <?php echo Yii::t('UpdaterModule.base', 'There is no new HumHub update available!'); ?>
        <br />
        
    </div>

</div>