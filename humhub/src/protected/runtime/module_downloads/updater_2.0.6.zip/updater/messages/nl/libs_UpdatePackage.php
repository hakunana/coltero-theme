<?php
return array (
  'Update download failed! (%error%)' => 'Update download mislukt! (%error%)',
);
