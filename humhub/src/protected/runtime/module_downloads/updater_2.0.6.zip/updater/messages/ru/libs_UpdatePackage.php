<?php
return array (
  'Update download failed! (%error%)' => 'Ошибка загрузки при обновлении! (%error%)',
);
