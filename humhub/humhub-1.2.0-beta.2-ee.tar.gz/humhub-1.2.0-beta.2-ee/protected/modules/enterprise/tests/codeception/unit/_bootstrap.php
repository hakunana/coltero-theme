<?php
/**
 * The bootstrapping of unit tests is done by yii\codeception\DbTestCase or tests\codeception\_support\HumHubDbTestCase
 * These classes will automatically load the config from @tests/codeception/config/unit.php
 * The default test config can be overwritten in @tests/config/unit.php
 */
