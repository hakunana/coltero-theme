Changelog
=========

1.2.1 - February 24, 2017
-----------------------
- Enh: Added SearchWidget, main template adjustment
- Enh: Use default accountTopMenu with showUserName option
- Fix: Added ico definition to head.php 
- Fix: Unexpected space chooser behaviour when result is empty

1.2.0 - February 05, 2017
-----------------------
- Enh: Raised compatiblity to HumHub 1.2
- Enh: Added new less theming
- Enh: Optimized main template
- Enh: Usage of new space chooser
- Enh: Pjax Adjustments

1.1.13 - Obtober 28, 2016
-----------------------
- Enh: Added JWT authentication module (luke-)

1.1.11 - August 22, 2016
-----------------------
- Enh: Added e-mail to group mapping features

1.1.10 - August 14, 2016
-----------------------
- Enh: Added auto removal of users from ldap handles spaces
- Enh: Added memberof attribute when not exists


1.1.2 - June 13, 2016
-----------------------
- Enh: Added e-mail whitelist

1.1.0 - May 24, 2016
-----------------------
- Enh: Added SOLR Driver

1.0.7 - June 6, 2016
-----------------------
- Fixed: HumHub 1.1 admin alignments

1.0.6 - April 11, 2016
-----------------------
- Fixed: Multi DropDown Select2 Alignment
- Fixed: Calendar intems overlap DropDown
- Enh: Updated translations

1.0.5 - March 25, 2016
-----------------------
- Fixed: Mobile Layouts
- Fixed: Brand logo layout fix
- Enh: Updated translations

1.0.4 - March 9, 2016
-----------------------
- Fixed: Brand Logo in sidebar
- Fixed: Mobile main content alignment in mobile navigation
- Fixed: use directory page size if set
- Enh: Handle LDAP parent groups
- Enh: Improved LDAP error handling

1.0.3 - Februrary 27, 2016
-----------------------
- Fixed: CSS Fixes
- Enh: Updated translations

1.0.2 - Februrary 2, 2016
-----------------------
- Enh: Updated translations
- Enh: Added LDAP Authclient