Updating - Enterprise Edition
=============================

The HumHub Enterprise Edition is delivered as module package in addition to the standard community edition.

Like any other module, available updates are displayed at: `Administration` -> `Modules` -> `Available updates`. 

> Info: You also need to keep the **HumHub** core platform up to date - More information: [Updating HumHub](../admin/updating-automatic.md)