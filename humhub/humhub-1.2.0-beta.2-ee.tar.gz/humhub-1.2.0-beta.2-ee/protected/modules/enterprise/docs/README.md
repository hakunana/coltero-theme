Enterprise Edition
==================

Getting Started
---------------
- [Installation](installation.md)
- [Updates](update.md)
- [Support](support.md)
- [Changelog](CHANGELOG.md)

Features
--------
- [Enterprise Theme](theme.md)
- [LDAP](ldap.md)
- [Space types](space-types.md)
- [E-Mail - Whitelisting](email-whitelisting.md)
- [E-Mail - Group Mapping](email-groupmapping.md)
- [SOLR - Search](solr.md)
- [JWT - SSO](jwt.md)
