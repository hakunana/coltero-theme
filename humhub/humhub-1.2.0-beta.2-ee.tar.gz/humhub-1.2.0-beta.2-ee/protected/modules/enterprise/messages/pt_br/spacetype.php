<?php
return array (
  '<i class="fa fa-plus"></i> %itemTitle%' => '<i class="fa fa-plus"></i> %itemTitle%',
  '<strong>Change</strong> type' => '<strong>Alterar</strong> tipo',
  '<strong>Create</strong> new %typeTitle%' => '<strong>Criar</strong> novo %typeTitle%',
  '<strong>Create</strong> new space type' => '<strong>Criar</strong> novo tipo de espaço',
  '<strong>Delete</strong> space type' => '<strong>Excluir</strong> tipo de espaço',
  '<strong>Edit</strong> space type' => '<strong>Editar</strong> tipo de espaço',
  'Create new type' => 'Criar novo tipo',
  'Here you can manage your space types, which can be used to categorize your spaces.' => 'Aqui você pode gerenciar seus tipos de espaço, que podem ser usados para categorizar seus espaços.',
  'Space Types' => 'Tipos de Espaços',
  'To delete the space type <strong>"{type}"</strong> you need to set an alternative type for existing spaces:' => 'Para excluir o tipo de espaço <strong>"{type}"</strong> você precisa definir um tipo alternativo para espaços existentes:',
  'Type' => 'Tipo',
  'Types' => 'Tipos',
  'e.g. Project' => 'ex. Projeto',
  'e.g. Projects' => 'ex. Projetos',
);
