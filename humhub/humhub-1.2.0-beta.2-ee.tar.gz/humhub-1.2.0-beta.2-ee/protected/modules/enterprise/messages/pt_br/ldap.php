<?php
return array (
  '<strong>Create</strong> new ldap mapping' => '<strong>Criar</strong> novo mapeamento ldap',
  '<strong>Edit</strong> ldap mapping' => '<strong>Editar</strong> mapeamento ldap',
  '<strong>LDAP</strong> member mapping' => 'Mapeamento de usuário <strong>LDAP</strong>',
  'Create new mapping' => 'Criar novo mapeamento',
  'Group' => 'Grupo',
  'ID' => 'ID',
  'LDAP' => 'LDAP',
  'LDAP DN' => 'LDAP DN',
  'LDAP Mapping' => 'Mapeamento LDAP',
  'Space ID' => 'ID do espaço',
);
