<?php
return array (
  '<strong>Create</strong> new ldap mapping' => 'Neue LDAP-Zuordnung <strong>erstellen</strong>',
  '<strong>Edit</strong> ldap mapping' => 'LDAP-Zuordnung <strong>bearbeiten</strong>',
  '<strong>LDAP</strong> member mapping' => '<strong>LDAP</strong> Mitglieder Zuordnung',
  'Create new mapping' => 'Neue Zuordnung erstellen',
  'Group' => 'Gruppe',
  'ID' => 'ID',
  'LDAP' => 'LDAP',
  'LDAP DN' => 'LDAP DN',
  'LDAP Mapping' => 'LDAP-Zuordnung',
  'Space ID' => 'Space ID',
);
