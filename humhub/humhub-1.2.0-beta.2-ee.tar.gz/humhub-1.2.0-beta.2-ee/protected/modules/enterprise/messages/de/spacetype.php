<?php
return array (
  '<i class="fa fa-plus"></i> %itemTitle%' => '<i class="fa fa-plus"></i> %itemTitle%',
  '<strong>Change</strong> type' => 'Spacetyp <strong>änderen</strong>',
  '<strong>Create</strong> new %typeTitle%' => 'Neuen %typeTitle% <strong>erstellen</strong>',
  '<strong>Create</strong> new space type' => '<strong>Erstelle</strong> neuen Spacetyp',
  '<strong>Delete</strong> space type' => 'Spacetyp <strong>löschen</strong>',
  '<strong>Edit</strong> space type' => 'Spacetyp <strong>bearbeiten</strong>',
  'Create new type' => 'Erstelle einen neuen Spacetyp',
  'Here you can manage your space types, which can be used to categorize your spaces.' => 'Hier können Sie Ihre Spacetypen verwalten, mit denen Sie Ihre  Spaces kategorisieren können.',
  'Space Types' => 'Spacetypen',
  'To delete the space type <strong>"{type}"</strong> you need to set an alternative type for existing spaces:' => 'Um den Spacetyp <strong>"{type}"</strong> löschen zu können, muss für vorhandene Spaces ein ander Spacetyp ausgewählt werden:',
  'Type' => 'Spacetyp',
  'Types' => 'Spacetypen',
  'e.g. Project' => 'z.B. Projekt',
  'e.g. Projects' => 'z.B. Projekte',
);
