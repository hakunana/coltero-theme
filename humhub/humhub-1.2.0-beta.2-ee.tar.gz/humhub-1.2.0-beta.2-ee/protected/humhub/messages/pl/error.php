<?php
return array (
  '<strong>Login</strong> required' => 'Pole <strong>Login</strong> jest wymagane',
  'An internal server error occurred.' => 'Wystąpił wewnętrzny błąd serwera',
  'You are not allowed to perform this action.' => 'Brak uprawnień do przeprowadzenia tej operacji.',
);
