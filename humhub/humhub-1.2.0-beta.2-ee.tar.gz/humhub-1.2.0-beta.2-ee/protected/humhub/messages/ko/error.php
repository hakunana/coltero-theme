<?php
return array (
  '<strong>Login</strong> required' => '<strong>로그인이</strong> 필요합니다',
  'An internal server error occurred.' => '서버 오류가 발생했습니다. 걱정 마세요! 당신의 잘못이 아닙니다!',
  'You are not allowed to perform this action.' => '이 액션을 수행할 권한이 부족합니다.',
);
