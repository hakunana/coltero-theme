<?php
return array (
  '<strong>Login</strong> required' => '<strong>Masuk</strong> diperlukan',
  'An internal server error occurred.' => 'Terjadi kesalahan server internal.',
  'You are not allowed to perform this action.' => 'Anda tidak diizinkan untuk melakukan aksi ini.',
);
