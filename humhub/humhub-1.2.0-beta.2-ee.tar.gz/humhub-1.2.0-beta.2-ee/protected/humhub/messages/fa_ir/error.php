<?php
return array (
  '<strong>Login</strong> required' => '<strong>ورود</strong> لازم است',
  'An internal server error occurred.' => 'يك مشكل در سرور به وجود آمده است',
  'You are not allowed to perform this action.' => 'شما قادر به انجام اين عمل نيستيد',
);
