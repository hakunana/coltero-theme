<?php
return array (
  '<strong>Login</strong> required' => 'يجب عليك <strong>تسجيل الدخول</strong> ',
  'An internal server error occurred.' => 'حدث خطأ داخلي في الخادم',
  'You are not allowed to perform this action.' => 'غير مسموح لك بتنفيذ هذا الإجراء.',
);
