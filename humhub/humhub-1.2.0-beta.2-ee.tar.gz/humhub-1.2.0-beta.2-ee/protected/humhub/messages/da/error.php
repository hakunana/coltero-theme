<?php
return array (
  '<strong>Login</strong> required' => '<strong>Log ind</strong> kræves',
  'An internal server error occurred.' => 'Der opstod en intern server fejl.',
  'You are not allowed to perform this action.' => 'Du har ikke tilladelse til at udføre denne handling.',
);
