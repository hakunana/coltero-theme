<?php
return array (
  '<strong>Login</strong> required' => '<strong>Login</strong> Requerido',
  'An internal server error occurred.' => 'Ocorreu um erro interno no servidor.',
  'You are not allowed to perform this action.' => 'Você não tem permissão para executar esta ação.',
);
