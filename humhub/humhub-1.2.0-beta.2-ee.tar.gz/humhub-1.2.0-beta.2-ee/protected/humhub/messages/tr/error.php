<?php
return array (
  '<strong>Login</strong> required' => 'Giriş Yapınız',
  'An internal server error occurred.' => 'Sunucu hatası oluştu.',
  'You are not allowed to perform this action.' => 'Bu eylemi gerçekleştirmek için izin gereklidir.',
);
