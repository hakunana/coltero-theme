<?php
return array (
  '<strong>Login</strong> required' => '<strong>Inloggen</strong> vereist',
  'An internal server error occurred.' => 'Er is een interne serverfout opgetreden.',
  'You are not allowed to perform this action.' => 'Je hebt niet de nodige rechten om deze actie uit te voeren.',
);
