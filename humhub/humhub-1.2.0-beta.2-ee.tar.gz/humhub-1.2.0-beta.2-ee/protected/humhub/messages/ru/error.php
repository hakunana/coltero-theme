<?php
return array (
  '<strong>Login</strong> required' => 'Необходима <strong>авторизация</strong>',
  'An internal server error occurred.' => 'Произошла внутренняя ошибка сервера.',
  'You are not allowed to perform this action.' => 'Вы не можете выполнить это действие.',
);
