<?php
return array (
  '<strong>Login</strong> required' => 'Je nutné <strong>být přihlášen(a)</strong>',
  'An internal server error occurred.' => 'Na serveru se vyskytla chyba.',
  'You are not allowed to perform this action.' => 'K této akci nemáte dostatečná oprávnění.',
);
