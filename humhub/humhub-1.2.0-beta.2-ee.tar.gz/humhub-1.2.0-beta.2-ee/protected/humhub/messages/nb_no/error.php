<?php
return array (
  '<strong>Login</strong> required' => '<strong>Logg inn</strong>이 påkrevd',
  'An internal server error occurred.' => 'En intern Server Feil',
  'You are not allowed to perform this action.' => 'Du har ikke lov til og gjøre denne handlingen.',
);
