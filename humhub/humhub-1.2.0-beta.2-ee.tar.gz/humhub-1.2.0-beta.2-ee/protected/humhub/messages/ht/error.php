<?php
return array (
  '<strong>Login</strong> required' => '<strong>Idantifikasyon ou</strong> rekòmande',
  'An internal server error occurred.' => 'Gen yon erè ki pase nan sèvè a.',
  'You are not allowed to perform this action.' => 'Ou pa gen dwa pou\'w fè aksyon sa a.',
);
